/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.utils.function;

/**
 * A functional interface that represents a supplier of results that can throw an exception.
 *
 * @param <T> the type of results supplied by this supplier
 * @param <E> the type of exception that can be thrown by this supplier
 */
public interface ThrowableSupplier<T, E extends Exception> {

    /**
     * Gets a result.
     *
     * @return a result
     * @throws E if an exception occurs
     */
    T get() throws E;
}
