/*
 * DBeaver - Universal Database Manager
 * Copyright (C) 2010-2026 DBeaver Corp and others
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.jkiss.utils.rpc;

import java.util.UUID;

public class RpcResponse {
    private final UUID messageId;
    private final String result;
    private final String error;

    public RpcResponse(UUID messageId, String result, String error) {
        this.messageId = messageId;
        this.result = result;
        this.error = error;
    }

    /**
     * Returns the unique identifier of the message. This identifier is used to match responses to requests.
     */
    public UUID messageId() {
        return messageId;
    }

    /**
     * Returns the result of the message.
     */
    public String result() {
        return result;
    }

    /**
     * Returns the error message of the message.
     */
    public String error() {
        return error;
    }
}
